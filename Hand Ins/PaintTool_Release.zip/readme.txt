// -- README -- \\

Some quick instructions:

The weird arrow is "undo shape"

Saving saves the image as "Paint Tool Image" in the "images" folder

To change the number of sides on the polygon tool, scroll the mouse wheel while drawing the shape

Scrolling any other time changes the brush size, which affects the brush and line tool

Shapes display over the top of the brush tool

Must be built in x86

To load your own stamp, use a black and white bitmap and place it in the 'images' folder and name it 'stamp.bmp'

Loaded stamps will ignore white pixels and place the rest of them as the current selected colour