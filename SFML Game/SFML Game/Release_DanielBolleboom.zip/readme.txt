IMPORTANT!!!!
MSI Afterburner has been found to cause issues. It tends to crash after a few levels. Please disable or uninstall MSI Afterburner
for an optimal experience.
The error message that shows up with it can appear anyway, it is an issue with OpenAL and is unavoidable. It also doesn't change
anything unless MSI Afterburner is active.
I am unaware of any similar programs also causing issues, however I would reccomend temporarily disabling them just to be safe. 

SOURCES:
Sound effects - Sourced from https://freesound.org/ and made in Chiptune
Sprites - Made in Mircosoft Paint and piskelapp.com
Music - Made by Jake Finlayson (AKA 3mourn)

CONTROLS:
Gameplay:
Move - WASD
Shoot - Left mouse button, projectiles will move towards the mouse cursor

Main menu:
Left click on Begin and Exit buttons to activate
M - Mute/unmute music

Debug window:
Escape - Open debug window
Left mouse button on squares - Enable/disable settings
Space - Cycle through debug values to change (only if "Enable Value Changing" is enabled in debug window)
Up/down arrow - Increase/decrease selected debug variable respectively (only if "Enable Value Changing" is enabled in debug window)

RECCOMENDED DEBUG VALUES:
Player shoot cooldown: 400
Player speed: 5
Bullet speed: 5

DEBUG CONTROLS:
T: Randomise level
Numbers 0 - 9 (NOT numpad): Select specific level based on index from 0 - 9